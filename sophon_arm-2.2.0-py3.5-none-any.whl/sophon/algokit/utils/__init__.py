"""Some utilities
"""
