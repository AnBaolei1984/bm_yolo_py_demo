"""sailalgokit source part
"""
