"""the implementation of speech algorithm
"""
