"""the implementation of computer vision segmentation algorithm
"""
