"""the implementation of computer vision
classification&&recognition algorithm

General classification
General feature extraction
...
"""
