"""implementation of some extend layers (optimize)

Region Proposal layer:
            face detection ssh
            object detection faster_rcnn
"""
