"""Algorithm Factory
"""
